﻿namespace LeDinhThang_2122110516.model
{
    public class Banner
    {
        public int Id { get; set; }
        public string BannerName { get; set; }
        public string Image { get; set; }
    }
}
